﻿namespace Api02.Models
{
    public class Rol
    {
        public int Id { get; set; }
        public string NombreRol { get; set; }    
    }
}
