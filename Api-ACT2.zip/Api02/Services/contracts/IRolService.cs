﻿using Api02.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Api02.Services.contracts
{
    public interface IRolService
    {
        Task<List<Rol>> GetList();
        Task<Rol> AgregaActualiza(Rol l, string t);
    }
}
