﻿using Api02.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;




namespace Api02.Business.Contracts
{
    public interface IRolRepository
    {
        Task<List<Rol>> GetList();
        Task<Rol> AgregaActualiza(Rol l, string t);
    }
}
