﻿using Api02.Business.Contracts;
using Api02.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Threading.Tasks;

namespace Api02.Business
{
    public class RolRepository : IRolRepository
    {
        private readonly string connec;

        public RolRepository(IConfiguration config)
        {
            connec = config.GetConnectionString("conBase");
        }

        public async Task<List<Rol>> GetList()
        {
            var list = new List<Rol>();

            using SqlConnection con = new SqlConnection(connec);
            using SqlCommand cmd = new SqlCommand("SELECT * FROM Rol", con);
            await con.OpenAsync();
            SqlDataReader dr = await cmd.ExecuteReaderAsync();

            while (await dr.ReadAsync())
            {
                list.Add(new Rol
                {
                    Id = (int)dr["Id"],
                    NombreRol = dr["NombreRol"].ToString()
                });
            }

            return list;
        }

        public async Task<Rol> AgregaActualiza(Rol l, string t)
        {
            using SqlConnection con = new SqlConnection(connec);
            string query = t == "c"
                ? "INSERT INTO Rol (NombreRol) VALUES (@NombreRol); SELECT SCOPE_IDENTITY();"
                : "UPDATE Rol SET NombreRol = @NombreRol WHERE Id = @Id; SELECT @Id";

            using SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@NombreRol", l.NombreRol);
            if (t == "u") cmd.Parameters.AddWithValue("@Id", l.Id);

            await con.OpenAsync();
            var result = await cmd.ExecuteScalarAsync();
            l.Id = int.Parse(result.ToString());
            return l;
        }
    }
}
