﻿using Api02.Models;
using Api02.Services.contracts;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Api02.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RolController : ControllerBase
    {
        private readonly IRolService _IRolService;

        public RolController(IRolService iTemp)
        {
            _IRolService = iTemp;
        }

        [HttpGet]
        public async Task<List<Rol>> GetList()
        {
            return await _IRolService.GetList();
        }

        [HttpPost("AgregaActualiza")]
        public async Task<Rol> AgregaActualiza(int Id, string NombreRol, string t)
        {
            Rol l = new Rol
            {
                Id = Id,
                NombreRol = NombreRol
            };
            return await _IRolService.AgregaActualiza(l, t);
        }
    }
}
